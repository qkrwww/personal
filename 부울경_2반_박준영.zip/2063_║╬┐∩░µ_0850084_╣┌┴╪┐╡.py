a = int(input())
b = list(map(int, input().split()))
b.sort()
c= a // 2
print(b[c])