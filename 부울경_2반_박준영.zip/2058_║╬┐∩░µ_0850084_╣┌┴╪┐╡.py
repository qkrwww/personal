a = list(input())
a = list(map(int,a))
b=sum(a)
print(b)